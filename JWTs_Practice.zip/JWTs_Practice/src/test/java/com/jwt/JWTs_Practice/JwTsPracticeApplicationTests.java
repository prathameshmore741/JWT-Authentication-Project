package com.jwt.JWTs_Practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwTsPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
