package com.jwt.JWTs_Practice.model;

public enum Role {
	ADMIN,
	USER
}
