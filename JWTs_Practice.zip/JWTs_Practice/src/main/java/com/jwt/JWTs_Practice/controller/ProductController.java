package com.jwt.JWTs_Practice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jwt.JWTs_Practice.model.Product;
import com.jwt.JWTs_Practice.repo.ProductRepository;

@RestController
@RequestMapping("/api/products")
public class ProductController {
	
	@Autowired
	private ProductRepository productRepository;
	
	@PostMapping("/add")
	//@PreAuthorize("hasAnyAuthority('ADMIN','USER')")
	@PreAuthorize("hasAnyRole('ADMIN','USER')")
	public ResponseEntity<?> addproduct(@RequestBody Product product){
		Product saved= productRepository.save(product);
		return ResponseEntity.ok(saved);
	}
	
	@GetMapping("/all")
	//@PreAuthorize("hasAuthority('ADMIN')")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<Product>> listAll(){
		return ResponseEntity.ok(productRepository.findAll());
	}
	
	// both roles can get single product	
	@GetMapping("/view/{id}")
	@PreAuthorize("hasAnyRole('ADMIN','USER')")
	public ResponseEntity<?> getProduct(@PathVariable Long id){
		return productRepository.findById(id).map(ResponseEntity::ok).orElseGet( () -> ResponseEntity.notFound().build());
	}
	
	// Admin & User can update
	@PutMapping("/update/{id}")
	@PreAuthorize("hasAnyRole('ADMIN','USER')")
	public ResponseEntity<?> updateProduct(@PathVariable Long id, @RequestBody Product product) {
		Optional<Product> existing = productRepository.findById(id);
		if (existing.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		Product p = existing.get();
		p.setName(product.getName());
		p.setDescription(product.getDescription());
		p.setPrice(product.getPrice());
		Product saved = productRepository.save(p);
		return ResponseEntity.ok(saved);
	}
		
	// Admin only delete
	@DeleteMapping("/delete/{id}")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<?> deleteProduct(@PathVariable Long id) {
		Optional<Product> existing = productRepository.findById(id);
		if (existing.isEmpty()) {
			return ResponseEntity.notFound().build();
		}
		productRepository.deleteById(id);
		return ResponseEntity.ok().body("Deleted");
	}

}
