package com.jwt.JWTs_Practice.security;

import java.security.Key;
import java.util.Date;
import java.util.function.Function;

import org.antlr.v4.runtime.misc.TestRig;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
	
	// Hardcoded secret
	private final String secret= "your_secret_key_your_secret_key_your_secret_key_12345";
	private final Key signingKey= Keys.hmacShaKeyFor(secret.getBytes());
	private final long jwtExpirationMs= 1000 * 60 * 5;		// 5 mins valid token
	
	public String generateToken(String username) {
		Date now= new Date();
		Date expiry= new Date(now.getTime() + jwtExpirationMs);
		return Jwts.builder()
				.setSubject(username)
				.setIssuedAt(now)
				.setExpiration(expiry)
				.signWith(signingKey, SignatureAlgorithm.HS256)
				.compact();
	}

	public boolean validateToken(String token, String username) {
		// TODO Auto-generated method stub
		final String u= extractUsername(token);
		return (u.equals(username) && !isTokenExpired(token));
	}
	
	public String extractUsername(String token) {
		// TODO Auto-generated method stub
		return extractClaim(token, Claims::getSubject);
	}
	
	public Date extractExpiration(String token) {
		return extractClaim(token, Claims::getExpiration);
	}
	
	public <T> T extractClaim(String token, Function<Claims, T> claimResolver) {
		final Claims claims=Jwts.parserBuilder()
				.setSigningKey(signingKey)
				.build()
				.parseClaimsJws(token)
				.getBody();
		return claimResolver.apply(claims);
	}
	
	private boolean isTokenExpired(String token) {
		return extractExpiration(token).before(new Date());
	}

}
