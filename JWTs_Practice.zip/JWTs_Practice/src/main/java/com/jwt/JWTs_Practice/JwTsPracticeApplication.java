package com.jwt.JWTs_Practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwTsPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwTsPracticeApplication.class, args);
	}

}


// This project is connected to mqsql. This is role based jwt authenticated project having CRUD operations for product