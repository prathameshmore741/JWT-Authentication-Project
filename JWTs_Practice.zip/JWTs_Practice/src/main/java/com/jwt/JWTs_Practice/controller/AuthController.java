package com.jwt.JWTs_Practice.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jwt.JWTs_Practice.dto.AuthRequest;
import com.jwt.JWTs_Practice.dto.AuthResponse;
import com.jwt.JWTs_Practice.dto.UserRegisterRequest;
import com.jwt.JWTs_Practice.model.User;
import com.jwt.JWTs_Practice.repo.UserRepository;
import com.jwt.JWTs_Practice.security.JwtUtil;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody @Valid AuthRequest request){
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
			String token= jwtUtil.generateToken(request.getUsername());
			return ResponseEntity.ok(new AuthResponse(token));
		} catch (AuthenticationException e) {
			// TODO: handle exception
			e.printStackTrace(); // 👈 ADD THIS LINE TEMPORARILY
			return ResponseEntity.status(401).body("Invalid Username/ Password");
		}
	}
	
	
	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody @Valid UserRegisterRequest userRequest){
		Optional<User> existing = userRepository.findByUsername(userRequest.getUsername());
		if(existing.isPresent()) {
			return ResponseEntity.badRequest().body("Username already exist, Please try another username..");
		}
		
		User user= new User();
		user.setUsername(userRequest.getUsername());
		user.setPassword(passwordEncoder.encode(userRequest.getPassword()));
		user.setRole(userRequest.getRole());
		userRepository.save(user);
		return ResponseEntity.ok("User Registered Successfully!!");
		
	}


}
