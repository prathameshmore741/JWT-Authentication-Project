package com.jwt.JWTs_Practice.security;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.net.http.HttpRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class JwtFilter extends OncePerRequestFilter{
	
	@Autowired
	private JwtUtil jwtUtil;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	private static final Logger logger= LoggerFactory.getLogger(JwtFilter.class);
	
	@Override
	public void doFilterInternal(@NonNull HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain) throws IOException, ServletException{
		
		/*	 
		 /register → no token required (user is new) 
		 /login → no token required (user authenticates and gets one) 
		 All other routes → token required (protected resources)	 
		 */
		
		// IMP - Skip token validation for public endpoints
	    String requestPath = request.getServletPath();
	    if (requestPath.startsWith("/login") || requestPath.startsWith("/register")) {
	        filterChain.doFilter(request, response);
	        return;
	    }
	    
	    final String authHeader= request.getHeader("Authorization");
		String username=null;
		String token=null;
		
		try {
			if(authHeader!=null && authHeader.startsWith("Bearer ")) {
				token= authHeader.substring(7);
				username=jwtUtil.extractUsername(token);
			}
		}catch (ExpiredJwtException e) {
			// TODO: handle exception
			logger.warn("JWT expired: {}", e.getMessage());
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			response.getWriter().write("Token expired, please login again");
			return;
		}catch (Exception e) {
			// TODO: handle exception
			logger.warn("JWT error: {}", e.getMessage());
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			response.getWriter().write("Invalid token");
			return;
		}
		
		if(username!=null && SecurityContextHolder.getContext().getAuthentication()==null) {
			UserDetails userDetails= userDetailsService.loadUserByUsername(username);
			if(jwtUtil.validateToken(token, userDetails.getUsername())) {
				UsernamePasswordAuthenticationToken authToken= new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(authToken);
			}
		}
		
		filterChain.doFilter(request, response);
	}
	
	
}
