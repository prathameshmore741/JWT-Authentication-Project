package com.jwt.JWTs_Practice.dto;

import java.util.Set;

import com.jwt.JWTs_Practice.model.Role;

import lombok.Data;

@Data
public class UserRegisterRequest {
	private String username;
	private String password;
	private Role role;
}
